# Ayran Launcher build

This source is a customized launcher build based on the Gladiolus PojavLauncher source.

Changes in this build:
- Ayran Launcher branding and launcher icon
- Custom main menu
- Dedicated Mods button
- Mod search configured for mods instead of modpacks
- Original Minecraft Java runtime/launch pipeline retained

Build with the repository Gradle wrapper and Android JDK/SDK environment.
